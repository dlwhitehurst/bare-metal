# bare-metal

A lab project to stretch the use of Ansible, Ansible collection and roles.



